#!/usr/bin/bash
./make.bat clean && ./make.bat html
