===============================================================
reader - Data readers for formats which are no-longer supported
===============================================================

.. automodule:: reader
    :members:
    :undoc-members:
    :special-members:
    :exclude-members: __dict__, __module__, __weakref__

