===================================================
pywarnings - Easy wrapper to ignore Python warnings
===================================================

.. automodule:: pywarnings
    :members:
    :undoc-members:
    :private-members: _WARN_TYPES
    :special-members:
    :exclude-members: __dict__, __module__, __weakref__

