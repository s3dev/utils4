=================================================
tickers - Wait tickers for long-running processes
=================================================

.. automodule:: tickers
    :members:
    :undoc-members:
    :special-members:
    :exclude-members: __dict__, __module__, __weakref__

    .. automethod:: _GenericWait.stop
