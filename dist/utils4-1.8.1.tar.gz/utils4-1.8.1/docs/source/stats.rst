===============================================
stats - Statistics methods without the overhead
===============================================

.. automodule:: stats
    :members:
    :undoc-members:
    :special-members:
    :exclude-members: __dict__, __module__, __weakref__
