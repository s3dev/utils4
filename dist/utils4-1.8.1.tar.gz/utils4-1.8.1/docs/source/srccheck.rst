=================================================
srccheck - Checksum functionality for source code
=================================================

.. automodule:: srccheck
    :members:
    :undoc-members:
    :special-members:
    :exclude-members: __dict__, __module__, __weakref__
