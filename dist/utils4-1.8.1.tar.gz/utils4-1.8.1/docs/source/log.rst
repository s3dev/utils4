============================================
log - Providing easy logging to your project
============================================

.. automodule:: log
    :members:
    :undoc-members:
    :special-members:
    :exclude-members: __dict__, __module__, __weakref__

