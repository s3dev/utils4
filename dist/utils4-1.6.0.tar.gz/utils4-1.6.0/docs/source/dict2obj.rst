=======================================================
dict2obj - Conversion tool for JSON structure to object
=======================================================

.. automodule:: dict2obj
    :members:
    :undoc-members:
    :private-members:
    :special-members:
    :exclude-members: __dict__, __module__, __weakref__

