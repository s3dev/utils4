=====================================================
user_interface - Format coloured text to the terminal
=====================================================

.. automodule:: user_interface
    :members:
    :undoc-members:
    :special-members:
    :exclude-members: __dict__, __module__, __weakref__

.. autoclass:: _Config
    :members:
    :private-members:
    :undoc-members:
    :special-members:
    :exclude-members: __dict__, __module__, __weakref__

