#!/usr/bin/env bash

./make.bat clean && ./make.bat html
