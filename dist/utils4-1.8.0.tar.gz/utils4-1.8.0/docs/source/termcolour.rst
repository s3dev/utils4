=================================================
termcolour - Easily add colour to terminal output
=================================================

.. automodule:: termcolour
    :members:
    :private-members:
    :undoc-members:
    :special-members:
    :exclude-members: __dict__, __module__, __weakref__

