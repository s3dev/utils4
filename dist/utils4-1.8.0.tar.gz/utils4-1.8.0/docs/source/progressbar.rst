===============================================
progressbar - A simple command line progess bar
===============================================

.. automodule:: progressbar
    :members:
    :undoc-members:
    :special-members:
    :exclude-members: __dict__, __module__, __weakref__

