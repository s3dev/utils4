=====================================================================
crypto - Extended functionality from the base64 and hashlib libraries
=====================================================================

.. automodule:: crypto
    :members:
    :undoc-members:
    :private-members:
    :special-members:
    :exclude-members: __dict__, __module__, __weakref__

