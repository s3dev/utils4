============================================================================
config - Adds support for automatically reading an application's config file
============================================================================
Library providing JSON-based config file loading functionality.

.. automodule:: config
    :members:
    :undoc-members:
    :private-members:
    :special-members:
    :exclude-members: __dict__, __module__, __weakref__

