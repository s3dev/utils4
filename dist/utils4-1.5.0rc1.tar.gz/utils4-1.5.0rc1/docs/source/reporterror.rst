=============================================
reporterror - Portable error reporting module
=============================================

.. automodule:: reporterror
    :members:
    :undoc-members:
    :special-members:
    :exclude-members: __dict__, __module__, __weakref__

