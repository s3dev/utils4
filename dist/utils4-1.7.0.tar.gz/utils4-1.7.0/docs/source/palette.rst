============================================
palette - Quick access to named CSS4 colours
============================================

.. automodule:: palette
    :members:
    :undoc-members:
    :special-members:
    :exclude-members: __dict__, __module__, __weakref__

