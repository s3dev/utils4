# -*- coding: utf-8 -*-

from utils3._version import __version__

