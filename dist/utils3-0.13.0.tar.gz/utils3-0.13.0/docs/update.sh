#!/usr/bin/env bash

./make.bat html
