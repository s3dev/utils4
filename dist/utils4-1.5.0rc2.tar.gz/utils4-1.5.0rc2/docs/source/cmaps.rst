============================================================
cmaps - Provides easy access to the matplotlib's colour maps
============================================================

.. automodule:: cmaps
    :members:
    :undoc-members:
    :private-members:
    :special-members:
    :exclude-members: __dict__, __module__, __weakref__

