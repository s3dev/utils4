=============================================
dfdiff - A pandas.DataFrame differencing tool
=============================================

.. automodule:: dfdiff
    :members:
    :undoc-members:
    :special-members:
    :exclude-members: __dict__, __module__, __weakref__

