==========================================
timedelta - Date and time delta calculator
==========================================

.. automodule:: timedelta
    :members:
    :undoc-members:
    :special-members:
    :exclude-members: __dict__, __module__, __weakref__

